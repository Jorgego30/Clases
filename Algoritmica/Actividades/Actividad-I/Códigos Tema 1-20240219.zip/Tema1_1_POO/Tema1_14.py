from Class_Empleados import Persona,Empleado

if __name__ == "__main__":
    print(Persona("Jose", 18))
    print(Empleado("Jose", 18, "Usc", "jangel@usc.es"))

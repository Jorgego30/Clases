from Class_Alumnos import Alumno

if __name__ == "__main__":
    print(str(Alumno('11222333A', "Jose", 25)))

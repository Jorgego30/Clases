from Class_Lineas import Linea

if __name__ == "__main__":
    l = Linea(1, 2, 3, 4)
    print("Línea:", l, "de tamaño:", l.calcula_longitud())
